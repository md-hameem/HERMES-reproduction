# Stage attribution screen

Inspected development questions; no original-method or population claim.

| Scope | Arm | Answered | Correct |
|---|---|---:|---:|
| main | A_history_both | 40 | 21 |
| main | B_independent_recent | 40 | 24 |
| main | C_hide_history_readout | 40 | 27 |
| main | D_independent_hide_readout | 40 | 25 |
| main | compact_recent4 | 40 | 25 |

A: H visible in encoding/readout. B: H masked during R encoding only. C: H masked at every question/decode call only. D: H masked at both stages. Compact: fresh recent-4 at compact positions.
B/D use a physical H mask validated against independent cache construction at preserved logical positions; they are not complete DSCache implementations.
H remains physically stored in A-D. C may retain historical information mixed indirectly into R. History-empty questions are null controls.
B, D and compact recent-4 must replay earlier choices. This run uses the 40 main questions.
Shared cache preparation/snapshots are logged separately; per-answer timing/peak allocation includes shared control snapshots and is not standalone algorithm efficiency.

## Matched construction contrasts

A and C here split recent encoding at the H/R boundary and use an explicit causal mask. The primary contrast is C versus D with identical recent groups and hidden history at readout.

| Contrast | Questions | Left wins | Right wins | Choice changes |
|---|---:|---:|---:|---:|
| primary_C_matched_vs_D | 40 | 2 | 0 | 2 |
| A_matched_vs_B | 40 | 0 | 3 | 3 |
| C_matched_vs_original_C | 40 | 0 | 0 | 0 |
| A_matched_vs_original_A | 40 | 0 | 0 | 0 |
| C_matched_vs_compact_recent4 | 40 | 3 | 1 | 6 |
| C_matched_vs_A_matched_readout | 40 | 7 | 1 | 8 |
