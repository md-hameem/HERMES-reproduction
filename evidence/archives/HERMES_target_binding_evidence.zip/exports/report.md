# Target binding under a fixed answer budget

Within StreamingBench. Original source overlap is unverified.

| Cohort | Selector | Correct / questions | Median component ms | p95 component ms |
|---|---|---:|---:|---:|
| causal_two_or_more_windows | recent | 156 / 269 | 248.2 | 368.2 |
| causal_two_or_more_windows | previous | 141 / 269 | 246.0 | 368.7 |
| causal_two_or_more_windows | global_relevance | 147 / 269 | 674.7 | 819.1 |
| causal_two_or_more_windows | target_only | 150 / 269 | 670.0 | 814.5 |
| causal_two_or_more_windows | mean | 152 / 269 | 920.9 | 1066.9 |
| causal_two_or_more_windows | conjunction | 147 / 269 | 920.1 | 1066.9 |
| all_questions | recent | 177 / 300 | 246.1 | 366.2 |
| all_questions | previous | 162 / 300 | 244.2 | 367.9 |
| all_questions | global_relevance | 168 / 300 | 660.7 | 815.1 |
| all_questions | target_only | 171 / 300 | 657.1 | 813.5 |
| all_questions | mean | 173 / 300 | 907.9 | 1059.9 |
| all_questions | conjunction | 168 / 300 | 907.9 | 1055.1 |
| text_rich_two_or_more_windows | recent | 13 / 23 | 228.3 | 396.9 |
| text_rich_two_or_more_windows | previous | 13 / 23 | 232.0 | 379.4 |
| text_rich_two_or_more_windows | global_relevance | 11 / 23 | 628.8 | 843.9 |
| text_rich_two_or_more_windows | target_only | 11 / 23 | 648.2 | 851.1 |
| text_rich_two_or_more_windows | mean | 11 / 23 | 901.8 | 1110.0 |
| text_rich_two_or_more_windows | conjunction | 10 / 23 | 896.8 | 1110.0 |

Component times sum serialized cache builds, required probes, and one answer from the shared replay.
They exclude frame decoding, feature extraction and stream maintenance. The oracle is diagnostic only.

Conjunction vs mean: -1.86 pp, 95% video bootstrap [-4.40, +0.37], 2 wins and 7 losses.

Conjunction vs recent: -3.35 pp, 95% video bootstrap [-7.64, +0.74], 14 wins and 23 losses.

Conjunction vs global_relevance: +0.00 pp, 95% video bootstrap [-3.40, +3.35], 9 wins and 9 losses.

Conjunction vs target_only: -1.12 pp, 95% video bootstrap [-4.40, +1.90], 9 wins and 12 losses.

Conjunction vs previous: +2.23 pp, 95% video bootstrap [-2.57, +7.01], 27 wins and 21 losses.
