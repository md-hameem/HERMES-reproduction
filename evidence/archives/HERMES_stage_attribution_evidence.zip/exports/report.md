# Stage attribution screen

Inspected development questions; no original-method or population claim.

| Scope | Arm | Answered | Correct |
|---|---|---:|---:|
| main | A_history_both | 40 | 21 |
| main | B_independent_recent | 40 | 24 |
| main | C_hide_history_readout | 40 | 27 |
| main | D_independent_hide_readout | 40 | 25 |
| main | compact_recent4 | 40 | 25 |
| long_204_q3 | A_history_both | 1 | 0 |
| long_204_q3 | B_independent_recent | 1 | 0 |
| long_204_q3 | C_hide_history_readout | 1 | 1 |
| long_204_q3 | D_independent_hide_readout | 1 | 1 |

A: H visible in encoding/readout. B: H masked during R encoding only. C: H masked at every question/decode call only. D: H masked at both stages. Compact: fresh recent-4 at compact positions.
B/D use a physical H mask validated against independent cache construction at preserved logical positions; they are not complete DSCache implementations.
H remains physically stored in A-D. C may retain historical information mixed indirectly into R. History-empty questions are null controls.
Long 204/q3 results are separate from the main 40-question matrix. A and compact must replay earlier choices or execution stops.
Shared cache preparation/snapshots are logged separately; per-answer timing/peak allocation includes shared control snapshots and is not standalone algorithm efficiency.
