# Construction selection development run

| Arm | Correct | Answered |
|---|---:|---:|
| selected_two | 26 | 40 |
| latest_two | 26 | 40 |
| attention_mass_two | 26 | 40 |
| no_history | 25 | 40 |
| all_history | 27 | 40 |
| compact_recent4 | 25 | 40 |

All arms have the same answer K/V budget. The shared history build is excluded from paired construction timing.
Attention-mass timing conservatively charges the shared scorer. Its standalone cost may be lower.
