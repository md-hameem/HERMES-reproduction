# Frozen short query-cache comparison

| Arm | Correct | Answers | Median query KV bytes |
|---|---:|---:|---:|
| compact_recent4 | 74 | 150 | 9793536.0 |
| latest_two_short_readout | 72 | 150 | 9793536.0 |
| all_history_short_readout | 70 | 150 | 9793536.0 |

Clip-disjoint within StreamingBench. Original source overlap is unverified.

Primary paired difference: -2.67 pp (95% video bootstrap -7.33, 1.33).
