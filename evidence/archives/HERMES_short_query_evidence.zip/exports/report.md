# Short query cache development run

| Arm | Correct | Answered | Median query KV bytes | Median answer seconds |
|---|---:|---:|---:|---:|
| full_contextual | 21 | 40 | 48328704.0 | 0.1569 |
| masked_contextual | 27 | 40 | 48328704.0 | 0.1613 |
| short_contextual | 27 | 40 | 9793536.0 | 0.1562 |
| compact_recent4 | 25 | 40 | 9793536.0 | 0.1547 |

Query KV bytes count retained K/V tensors. Answer timing excludes restore and cache construction.
The same 40 development questions are used. Timing does not measure total live memory or whole-system latency.
