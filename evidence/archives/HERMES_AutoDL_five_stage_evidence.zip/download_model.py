
import json,sys
from huggingface_hub import snapshot_download
path=snapshot_download(repo_id=sys.argv[1],revision=sys.argv[2],cache_dir=sys.argv[3],
 allow_patterns=['*.json','*.safetensors','*.txt','*.model','*.vocab','tokenizer.*','merges.txt'],
 ignore_patterns=['onnx/*','*.onnx','*.bin','*.msgpack'])
with open(sys.argv[4],'w') as f:json.dump(str(path),f)
print('MODEL_SNAPSHOT='+str(path),flush=True)
