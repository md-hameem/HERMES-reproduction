#!/usr/bin/env python3
"""Resumable HERMES/FIFO/ablation runner. Official tracked source is never edited."""
import argparse
import ast
import contextlib
import csv
import gc
import hashlib
import inspect
import json
import os
import random
import re
import sys
import tempfile
import textwrap
import time
import types
from pathlib import Path

import numpy as np
import pandas as pd
import torch

KEY = ["video_id", "qa_index"]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def stable_json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def annotation_identity(records):
    return [{"video_id": str(x["video_id"]), "conversations": x["conversations"]} for x in records]


def safe_name(value):
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value))
    assert value and value not in {".", ".."}
    return value


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False))
    os.replace(temporary, path)


def atomic_csv(path, frame):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False, quoting=csv.QUOTE_NONNUMERIC)
    os.replace(temporary, path)


def expected_rows(video):
    rows = []
    for index, qa in enumerate(video["conversations"]):
        choices = qa.get("choices")
        answer = qa.get("answer")
        assert choices and answer in choices
        rows.append({"question": str(qa["question"]), "choices": choices,
                     "answer": answer, "correct_choice": "ABCDEFGH"[choices.index(answer)],
                     "task": qa.get("task", qa.get("question_type", video.get("task")))})
    return rows


def validate_video_csv(path, video):
    frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    expected = expected_rows(video)
    assert len(frame) == len(expected), (path, len(frame), len(expected))
    assert frame.video_id.astype(str).eq(str(video["video_id"])).all()
    assert not frame[["question", "pred_answer", "pred_choice", "qa_acc"]].isna().any().any()
    assert pd.to_numeric(frame.qa_acc, errors="coerce").isin([0, 100]).all()
    for index, row in frame.iterrows():
        target = expected[index]
        assert str(row.question).strip() == target["question"].strip()
        assert ast.literal_eval(row.choices) == target["choices"]
        assert str(row.answer) == str(target["answer"])
        assert str(row.correct_choice) == target["correct_choice"]
        parsed = str(row.pred_choice).strip().upper() == target["correct_choice"]
        assert parsed == (float(row.qa_acc) == 100.0), (path, index)
        if "task" in frame and target["task"] is not None:
            assert str(row.task) == str(target["task"])
    frame["qa_index"] = range(len(frame))
    frame["correct"] = pd.to_numeric(frame.qa_acc).eq(100).astype(int)
    return frame


def fifo_keep_indices(current_lengths, visual_start_idx, kv_size):
    assert visual_start_idx >= 0 and kv_size > 0
    output = []
    for length in current_lengths:
        assert length >= visual_start_idx
        visual = length - visual_start_idx
        keep_visual = min(kv_size, visual)
        prefix = torch.arange(visual_start_idx, dtype=torch.long)
        recent = torch.arange(length - keep_visual, length, dtype=torch.long)
        output.append(torch.cat([prefix, recent]))
    return output


def predict_and_compress_fifo(self):
    """Matched FIFO: prefix + newest visual tokens, no pseudo-query or summary."""
    if self.kv_cache is None:
        return
    from inference.reindex_1d import (compute_cos_sin_for_positions, rotary_delta,
                                      apply_rotary_delta_to_keys_only)
    lengths = [k.shape[2] for k, v in self.kv_cache]
    current_max = max(lengths)
    if current_max > self.kv_size:
        keep_per_layer = fifo_keep_indices(lengths, self.visual_start_idx, self.kv_size)
        device = self.device
        max_pos = getattr(self.language_model.config, "max_position_embeddings", 32768)
        threshold = max_pos - 1024
        current_position = max((p[-1].item() for p in self._position_ids_cache
                                if p is not None and p.numel()), default=0)
        compact = current_position > threshold if self.streaming else True
        old_positions = [p.clone() if p is not None else torch.arange(n, device=device)
                         for p, n in zip(self._position_ids_cache, lengths)]
        new_cache, after = [], []
        for layer, ((keys, values), keep) in enumerate(zip(self.kv_cache, keep_per_layer)):
            keep = keep.to(device=device, dtype=torch.long)
            assert keep.numel() <= lengths[layer]
            kept_k = torch.index_select(keys, 2, keep)
            kept_v = torch.index_select(values, 2, keep)
            old_pos = old_positions[layer].index_select(0, keep)
            if compact:
                new_pos = torch.arange(keep.numel(), device=device, dtype=torch.long)
                cos_old, sin_old = compute_cos_sin_for_positions(
                    self.language_model, len(old_pos), old_pos, keys.dtype, device)
                cos_new, sin_new = compute_cos_sin_for_positions(
                    self.language_model, len(new_pos), new_pos, keys.dtype, device)
                cos_delta, sin_delta = rotary_delta(cos_old, sin_old, cos_new, sin_new)
                kept_k = apply_rotary_delta_to_keys_only(kept_k, cos_delta, sin_delta)
            else:
                new_pos = old_pos
            new_cache.append((kept_k.contiguous(), kept_v.contiguous()))
            self._position_ids_cache[layer] = new_pos.clone().contiguous()
            after.append(kept_k.shape[2])
        self.kv_cache = new_cache
        self.token_activity_cache = [None for _ in range(self.num_layers)]
        expected = self.visual_start_idx + min(self.kv_size, max(lengths) - self.visual_start_idx)
        assert max(after) == min(after) == expected, (after, expected)
        print(f"FIFO_COMPRESSION before_max={current_max} after_min={min(after)} "
              f"after_max={max(after)} budget={self.kv_size} compacted={compact}", flush=True)
    print(f"GPU memory usage: {self.get_gpu_memory_usage_gb()} GB", flush=True)


def _transform_method(model, method_name, replacements):
    """Compile an exact, source-checked method variant and bind only to this instance."""
    import inference.llavaov_hermes as official
    original = inspect.getsource(getattr(official.LlavaOneVision_Hermes, method_name))
    source = textwrap.dedent(original)
    def outside_class_indent(text):
        return "\n".join(line[4:] if line.startswith("    ") else line for line in text.split("\n"))
    for replacement in replacements:
        if len(replacement) == 3:
            start_marker, end_marker, new = replacement
            assert source.count(start_marker) == 1 and source.count(end_marker) == 1
            start = source.index(start_marker)
            end = source.index(end_marker, start)
            source = source[:start] + new + source[end:]
        else:
            old, new = replacement
            old, new = outside_class_indent(old), outside_class_indent(new)
            assert source.count(old) == 1, (method_name, old, source.count(old))
            source = source.replace(old, new)
    namespace = dict(vars(official))
    exec(compile(source, f"<{method_name}_ablation>", "exec"), namespace)
    bound = types.MethodType(namespace[method_name], model)
    setattr(model, method_name, bound)
    return source


def install_ablation(model, method, patch_dir):
    if method == "hermes":
        return []
    if method == "fifo":
        model.predict_and_compress = types.MethodType(predict_and_compress_fifo, model)
        model.fifo_control = True
        return ["predict_and_compress_fifo"]
    written = []
    if method == "no_smoothing":
        source = _transform_method(model, "prune_kv_cache_by_attention", [(
            "    refined_scores = [s.clone() for s in layer_raw_scores]",
            "    for layer_idx, score in enumerate(refined_scores):",
            "    refined_scores = layer_raw_scores  # ABLATION: no cross-layer smoothing\n\n")])
        written.append(("prune_kv_cache_by_attention.py", source))
    elif method == "no_summary":
        source1 = _transform_method(model, "prune_kv_cache_by_attention", [(
            "                layer_budget = max(0, layer_budget - 1)",
            "                layer_budget = layer_budget  # ABLATION: no summary slot reserved")])
        source2 = _transform_method(model, "_shrink_positions_and_rerotate_keys", [(
            "            is_long_term = (layer_idx >= self.long_term_threshold)",
            "            is_long_term = False  # ABLATION: no summary token")])
        written.extend([("prune_kv_cache_by_attention.py", source1),
                        ("_shrink_positions_and_rerotate_keys.py", source2)])
    elif method == "uniform_layers":
        new = """        # ABLATION: common mixed-query/recency policy; retain depth labels only
        # for the independent smoothing and summary-token mechanisms.
        layer_type = ("short-term" if layer_idx < self.short_term_threshold else
                      "long-term" if layer_idx >= self.long_term_threshold else "mid-term")
        layer_attn_weights = attn_weights_mixed[layer_idx]
        question_len = question_len_mixed
        layer_recency_alpha = 0.5
        k = 10.25
"""
        source = _transform_method(model, "prune_kv_cache_by_attention", [
            ("        # Memory hierarchy mode", "        visual_attn_weights =", new)])
        written.append(("prune_kv_cache_by_attention.py", source))
    elif method == "no_position_reindex":
        replacements = [
            ("            if should_compact:\n                new_pos_kept = torch.arange(len(safe_idx), device=device, dtype=torch.long)",
             "            if should_compact and not getattr(self, '_ablate_position_reindex', False):\n                new_pos_kept = torch.arange(len(safe_idx), device=device, dtype=torch.long)"),
            ("            if should_compact:\n                cos_old, sin_old = compute_cos_sin_for_positions(",
             "            if should_compact and not getattr(self, '_ablate_position_reindex', False):\n                cos_old, sin_old = compute_cos_sin_for_positions("),
            ("                    if should_compact:\n                        summary_pos_id = len(safe_idx)",
             "                    if should_compact and not getattr(self, '_ablate_position_reindex', False):\n                        summary_pos_id = len(safe_idx)"),
        ]
        model._ablate_position_reindex = True
        source = _transform_method(model, "_shrink_positions_and_rerotate_keys", replacements)
        written.append(("_shrink_positions_and_rerotate_keys.py", source))
    else:
        raise ValueError(method)
    patch_dir = Path(patch_dir)
    patch_dir.mkdir(parents=True, exist_ok=True)
    for filename, source in written:
        (patch_dir / filename).write_text(source)
    return [name for name, _ in written]


def synchronize():
    if torch.cuda.is_available():
        torch.cuda.synchronize()


def timed_bind(model, attribute, event_name, events):
    original = getattr(model, attribute)
    def timed(*args, **kwargs):
        synchronize()
        start = time.perf_counter()
        try:
            return original(*args, **kwargs)
        finally:
            synchronize()
            event = {"event": event_name, "seconds": time.perf_counter() - start,
                     "allocated_gib": torch.cuda.memory_allocated() / 1024**3,
                     "reserved_gib": torch.cuda.memory_reserved() / 1024**3}
            if event_name == "encode" and args and hasattr(args[0], "shape"):
                event["frames"] = int(args[0].shape[0])
            if event_name in {"prune", "compression_path", "answer"} and getattr(model, "kv_cache", None) is not None:
                lengths = [k.shape[2] for k, v in model.kv_cache]
                event["cache_min"] = min(lengths)
                event["cache_max"] = max(lengths)
            events.append(event)
    setattr(model, attribute, timed)
    return original


def instrument_model(model):
    events, originals = [], {}
    for attribute, name in [("encode_video_chunk", "encode"),
                            ("pseudo_forward", "pseudo_forward"),
                            ("apply_kv_cache_pruning_strict", "prune"),
                            ("question_answering", "answer")]:
        originals[attribute] = timed_bind(model, attribute, name, events)
    return events, originals


def event_totals(events):
    output = {}
    for name in ("encode", "pseudo_forward", "prune", "answer", "compression_path"):
        selected = [float(x["seconds"]) for x in events if x["event"] == name]
        output[name + "_n"] = len(selected)
        output[name + "_s"] = float(sum(selected))
        output[name + "_median_s"] = float(np.median(selected)) if selected else None
        output[name + "_p95_s"] = float(np.quantile(selected, .95)) if selected else None
    output["encoded_frames"] = sum(int(x.get("frames", 0)) for x in events if x["event"] == "encode")
    caches = [int(x["cache_max"]) for x in events if "cache_max" in x]
    output["max_cache_tokens"] = max(caches) if caches else None
    return output


def config_identity(args, annotation, repo):
    source_files = ["inference/llavaov_hermes.py", "inference/abstract_hermes.py",
                    "inference/reindex_1d.py", "video_qa/base.py", "video_qa/hermes_vqa.py"]
    return {
        "method": args.method, "kv_size": args.kv_size, "sample_fps": args.sample_fps,
        "streaming": True, "seed": 2024, "decode": "greedy; repetition_penalty=1.1",
        "model_path_identity": Path(args.model_path).name,
        "annotation_sha256": stable_json(annotation_identity(annotation)).encode(),
        "source_sha256": {name: sha256(Path(repo) / name) for name in source_files},
        "runner_sha256": sha256(__file__),
    }


def run_one_video(analyzer, video, method, output_dir, config_hash):
    model = analyzer.qa_model
    video_id = str(video["video_id"])
    stem = safe_name(video_id)
    video_csv = output_dir / "videos" / f"{stem}.csv"
    metrics_json = output_dir / "video_metrics" / f"{stem}.json"
    if video_csv.is_file() and metrics_json.is_file():
        metrics = json.loads(metrics_json.read_text())
        if metrics.get("config_hash") == config_hash and metrics.get("status") == "complete":
            try:
                frame = validate_video_csv(video_csv, video)
                return frame, metrics, True
            except Exception as exc:
                print(f"REJECT_CHECKPOINT video={video_id} error={type(exc).__name__}; quarantining", flush=True)
    # Reject partial evidence; preserve it outside the active checkpoint namespace.
    incomplete = output_dir / "incomplete" / f"{stem}_{int(time.time())}"
    if video_csv.exists() or metrics_json.exists():
        incomplete.mkdir(parents=True, exist_ok=True)
        if video_csv.exists():
            os.replace(video_csv, incomplete / video_csv.name)
        if metrics_json.exists():
            os.replace(metrics_json, incomplete / metrics_json.name)
    analyzer.record = []
    events, instrumented_originals = instrument_model(model)
    base_predict = model.predict_and_compress
    timed_bind(model, "predict_and_compress", "compression_path", events)
    synchronize()
    torch.cuda.empty_cache()
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    start = time.perf_counter()
    started = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    try:
        analyzer.analyze_a_video(video)
        synchronize()
        frame = pd.DataFrame(analyzer.record)
        validate_video_csv(frame.assign(qa_index=range(len(frame))), video) if False else None
        # Validate an actual serialized checkpoint, not an in-memory substitute.
        atomic_csv(video_csv, frame)
        checked = validate_video_csv(video_csv, video)
        elapsed = time.perf_counter() - start
        metrics = {"video_id": video_id, "method": method, "status": "complete",
                   "config_hash": config_hash, "started_utc": started,
                   "wall_s": elapsed, "questions": len(checked),
                   "correct": int(checked.correct.sum()),
                   "accuracy_pct": float(100 * checked.correct.mean()),
                   "peak_allocated_gib": torch.cuda.max_memory_allocated() / 1024**3,
                   "peak_reserved_gib": torch.cuda.max_memory_reserved() / 1024**3,
                   "duration_category": video.get("duration_category"),
                   "events": events}
        metrics.update(event_totals(events))
        atomic_json(metrics_json, metrics)
    except Exception:
        # A thrown error leaves no complete marker and therefore cannot be reused.
        raise
    finally:
        model.predict_and_compress = base_predict
        for attribute, original in instrumented_originals.items():
            setattr(model, attribute, original)
        model.clear_cache()
        gc.collect()
        torch.cuda.empty_cache()
    return checked, metrics, False


def run_experiment(args):
    from inference.llavaov_hermes import load_model
    from video_qa.hermes_vqa import HermesVQA
    repo = Path(args.repo).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    annotation = json.loads(Path(args.annotation).read_text())
    assert len(annotation) == args.expected_videos
    assert sum(len(x["conversations"]) for x in annotation) == args.expected_questions
    random.seed(2024)
    np.random.seed(2024)
    torch.manual_seed(2024)
    identity = config_identity(args, annotation, repo)
    identity["annotation_sha256"] = hashlib.sha256(identity["annotation_sha256"]).hexdigest()
    config_hash = hashlib.sha256(stable_json(identity).encode()).hexdigest()
    atomic_json(output_dir / "config.json", {**identity, "config_hash": config_hash})
    print("RUN_CONFIG_HASH=" + config_hash, flush=True)
    model, processor = load_model(model_path=args.model_path, kv_size=args.kv_size,
                                  streaming=True, sample_fps=args.sample_fps)
    patches = install_ablation(model, args.method, output_dir / "patches")
    print("INSTANCE_PATCHES=" + json.dumps(patches), flush=True)
    analyzer = HermesVQA(anno=[], save_dir=str(output_dir), sample_fps=args.sample_fps,
                         qa_model=model, qa_processor=processor)
    frames, metrics, reused = [], [], 0
    for index, video in enumerate(annotation):
        frame, metric, was_reused = run_one_video(analyzer, video, args.method, output_dir, config_hash)
        frames.append(frame)
        metrics.append({k: v for k, v in metric.items() if k != "events"})
        reused += int(was_reused)
        print(f"VIDEO_PROGRESS {index + 1}/{len(annotation)} video_id={video['video_id']} "
              f"reused={was_reused} acc={metric['accuracy_pct']:.2f} wall_s={metric['wall_s']:.3f}", flush=True)
    final = pd.concat(frames, ignore_index=True)
    assert len(final) == args.expected_questions
    assert final.video_id.nunique() == args.expected_videos
    atomic_csv(output_dir / "1_0.csv", final.drop(columns=["correct"]))
    atomic_csv(output_dir / "video_summary.csv", pd.DataFrame(metrics))
    complete = {"status": "complete", "method": args.method, "kv_size": args.kv_size,
                "config_hash": config_hash, "videos": len(annotation), "questions": len(final),
                "correct": int(final.correct.sum()), "accuracy_pct": float(100 * final.correct.mean()),
                "reused_videos_this_invocation": reused,
                "finished_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    atomic_json(output_dir / "run_complete.json", complete)
    print("RUN_COMPLETE=" + json.dumps(complete), flush=True)


def selftest():
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        video = {"video_id": "synthetic_only", "conversations": [
            {"question": f"q{i}", "choices": ["a", "b"], "answer": "a"} for i in range(2)]}
        good = pd.DataFrame([{"video_id": "synthetic_only", "question": f"q{i}",
                              "choices": str(["a", "b"]), "answer": "a", "correct_choice": "A",
                              "pred_answer": "A", "pred_choice": "A", "qa_acc": 100} for i in range(2)])
        atomic_csv(root / "good.csv", good)
        assert len(validate_video_csv(root / "good.csv", video)) == 2
        bad = good.copy()
        bad.loc[1, "question"] = "wrong"
        atomic_csv(root / "bad.csv", bad)
        try:
            validate_video_csv(root / "bad.csv", video)
            raise AssertionError("malformed evidence was accepted")
        except AssertionError:
            pass
        indices = fifo_keep_indices([14, 30, 114], 14, 10)
        assert [x.tolist() for x in indices] == [list(range(14)), list(range(14)) + list(range(20, 30)),
                                                list(range(14)) + list(range(104, 114))]
        atomic_json(root / "atomic.json", {"ok": True})
        assert json.loads((root / "atomic.json").read_text())["ok"]
    print("SELFTEST_PASS: synthetic fixtures only; no research result written", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--selftest", action="store_true")
    parser.add_argument("--repo")
    parser.add_argument("--annotation")
    parser.add_argument("--output_dir")
    parser.add_argument("--model_path")
    parser.add_argument("--method", choices=["hermes", "fifo", "no_smoothing", "no_summary",
                                               "uniform_layers", "no_position_reindex"])
    parser.add_argument("--kv_size", type=int)
    parser.add_argument("--sample_fps", type=float, default=.5)
    parser.add_argument("--expected_videos", type=int)
    parser.add_argument("--expected_questions", type=int)
    args = parser.parse_args()
    if args.selftest:
        selftest()
        return
    assert args.expected_videos and args.expected_questions and args.kv_size
    run_experiment(args)


if __name__ == "__main__":
    main()
