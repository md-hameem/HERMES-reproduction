#!/usr/bin/env python3
"""Same-session, video-interleaved HERMES/FIFO efficiency comparison."""
import argparse
import importlib.util
import json
import random
import time
import types
from pathlib import Path

import numpy as np
import pandas as pd
import torch


def load_runner(path):
    spec = importlib.util.spec_from_file_location("experiment_runner", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--runner", required=True)
    parser.add_argument("--annotation", required=True)
    parser.add_argument("--model_path", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--videos", type=int, default=10)
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument("--kv_size", type=int, default=4000)
    args = parser.parse_args()
    assert args.videos == 10 and args.repetitions == 3 and args.kv_size == 4000
    R = load_runner(args.runner)
    from inference.llavaov_hermes import load_model
    from video_qa.hermes_vqa import HermesVQA
    annotation = json.loads(Path(args.annotation).read_text())[:args.videos]
    assert len(annotation) == 10 and sum(len(x["conversations"]) for x in annotation) == 50
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    random.seed(2024)
    np.random.seed(2024)
    torch.manual_seed(2024)
    model, processor = load_model(model_path=args.model_path, kv_size=args.kv_size,
                                  streaming=True, sample_fps=.5)
    hermes_predict = model.predict_and_compress
    fifo_predict = types.MethodType(R.predict_and_compress_fifo, model)
    analyzer = HermesVQA(anno=[], save_dir=str(output), sample_fps=.5,
                         qa_model=model, qa_processor=processor)
    order_path = output / "execution_order.csv"
    order = pd.read_csv(order_path).to_dict("records") if order_path.is_file() else []
    order_keys = {(int(x["repetition"]), str(x["video_id"]), x["method"]) for x in order}
    for repetition in range(args.repetitions):
        for video_index, video in enumerate(annotation):
            # ABBA-like ordering: reverse treatment order on alternating videos/repetitions.
            methods = ["hermes", "fifo"] if (repetition + video_index) % 2 == 0 else ["fifo", "hermes"]
            for method in methods:
                key = (repetition, str(video["video_id"]), method)
                target = output / f"repeat{repetition}" / method / R.safe_name(video["video_id"])
                target.mkdir(parents=True, exist_ok=True)
                csv_path, json_path = target / "predictions.csv", target / "metrics.json"
                if csv_path.is_file() and json_path.is_file():
                    metric = json.loads(json_path.read_text())
                    if metric.get("status") == "complete":
                        R.validate_video_csv(csv_path, video)
                        print(f"REUSE_INTERLEAVED rep={repetition} video={video['video_id']} method={method}", flush=True)
                        continue
                for path in (csv_path, json_path):
                    if path.exists():
                        path.rename(path.with_suffix(path.suffix + f".incomplete_{int(time.time())}"))
                model.predict_and_compress = hermes_predict if method == "hermes" else fifo_predict
                analyzer.record = []
                events, originals = R.instrument_model(model)
                base_predict = model.predict_and_compress
                R.timed_bind(model, "predict_and_compress", "compression_path", events)
                R.synchronize()
                torch.cuda.empty_cache()
                torch.cuda.reset_peak_memory_stats()
                start = time.perf_counter()
                started = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                try:
                    analyzer.analyze_a_video(video)
                    R.synchronize()
                    frame = pd.DataFrame(analyzer.record)
                    R.atomic_csv(csv_path, frame)
                    checked = R.validate_video_csv(csv_path, video)
                    elapsed = time.perf_counter() - start
                    metric = {"status": "complete", "repetition": repetition,
                              "video_index": video_index, "video_id": str(video["video_id"]),
                              "method": method, "kv_size": args.kv_size, "started_utc": started,
                              "wall_s": elapsed, "questions": len(checked),
                              "correct": int(checked.correct.sum()),
                              "accuracy_pct": float(100 * checked.correct.mean()),
                              "peak_allocated_gib": torch.cuda.max_memory_allocated() / 1024**3,
                              "peak_reserved_gib": torch.cuda.max_memory_reserved() / 1024**3,
                              "events": events}
                    metric.update(R.event_totals(events))
                    R.atomic_json(json_path, metric)
                    order.append({"repetition": repetition, "video_index": video_index,
                                  "video_id": str(video["video_id"]), "method": method,
                                  "started_utc": started, "wall_s": elapsed})
                    R.atomic_csv(order_path, pd.DataFrame(order))
                    print(f"INTERLEAVED_COMPLETE rep={repetition} video={video['video_id']} "
                          f"method={method} wall_s={elapsed:.3f}", flush=True)
                finally:
                    model.predict_and_compress = base_predict
                    for attribute, original in originals.items():
                        setattr(model, attribute, original)
                    model.clear_cache()
    complete = []
    for repetition in range(args.repetitions):
        for video in annotation:
            for method in ("hermes", "fifo"):
                target = output / f"repeat{repetition}" / method / R.safe_name(video["video_id"])
                assert json.loads((target / "metrics.json").read_text())["status"] == "complete"
                R.validate_video_csv(target / "predictions.csv", video)
                complete.append((repetition, str(video["video_id"]), method))
    assert len(complete) == 60 and len(set(complete)) == 60
    R.atomic_json(output / "complete.json", {"status": "complete", "video_runs": 60,
                  "videos": 10, "repetitions": 3, "methods": ["hermes", "fifo"], "kv_size": 4000})
    print("INTERLEAVED_EFFICIENCY_COMPLETE=60_video_runs", flush=True)


if __name__ == "__main__":
    main()
