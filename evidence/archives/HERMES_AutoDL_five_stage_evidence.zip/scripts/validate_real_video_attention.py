#!/usr/bin/env python3
"""Differential pseudo-query attention on a real 16-frame visual KV cache."""
import argparse
import gc
import hashlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from decord import VideoReader
from transformers.cache_utils import DynamicCache


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_first_chunk(video_path, sample_fps=.5, frames=16):
    reader = VideoReader(video_path, num_threads=1)
    fps = round(reader.get_avg_fps())
    step = int(fps / sample_fps)
    assert step > 0
    indices = list(range(0, len(reader), step))[:frames]
    assert len(indices) == frames, (video_path, len(indices))
    return torch.from_numpy(reader.get_batch(indices).asnumpy())


def manual_attention(model, input_ids, past_key_values, causal):
    """Current frozen-hidden-state computation, optionally with causal masking."""
    from inference.reindex_1d import _get_rotary_module, apply_rotary_pos_emb_1d
    starts = model._get_next_start_pos_per_layer()
    q_len, batch = input_ids.shape[1], input_ids.shape[0]
    hidden_states = model.get_input_embeddings()(input_ids)
    config = model.language_model.config
    heads, kv_heads = config.num_attention_heads, config.num_key_value_heads
    head_dim = config.hidden_size // heads
    output = []
    for layer_index in range(config.num_hidden_layers):
        layer = model.language_model.model.layers[layer_index]
        past_k, past_v = past_key_values[layer_index]
        positions = model._build_position_ids(starts[layer_index], q_len, batch)
        normalized = layer.input_layernorm(hidden_states)
        attention = layer.self_attn
        query = attention.q_proj(normalized).view(batch, q_len, heads, head_dim).transpose(1, 2)
        key = attention.k_proj(normalized).view(batch, q_len, kv_heads, head_dim).transpose(1, 2)
        value = attention.v_proj(normalized).view(batch, q_len, kv_heads, head_dim).transpose(1, 2)
        rotary = _get_rotary_module(model.language_model)
        cos, sin = rotary(value, positions.max().item() + 1)
        cos, sin = cos[positions].unsqueeze(1), sin[positions].unsqueeze(1)
        query = apply_rotary_pos_emb_1d(query, cos, sin)
        key = apply_rotary_pos_emb_1d(key, cos, sin)
        key = torch.cat([past_k, key], dim=2)
        if kv_heads != heads:
            key = torch.repeat_interleave(key, heads // kv_heads, dim=1)
        weights = torch.matmul(query.float(), key.float().transpose(-2, -1)) / math.sqrt(head_dim)
        if causal:
            past_len = past_k.shape[2]
            causal_mask = torch.ones(q_len, q_len, dtype=torch.bool, device=weights.device).tril()
            allowed = torch.cat([torch.ones(q_len, past_len, dtype=torch.bool, device=weights.device),
                                 causal_mask], dim=1)
            weights = weights.masked_fill(~allowed, torch.finfo(weights.dtype).min)
        output.append(F.softmax(weights, dim=-1, dtype=torch.float32).to(query.dtype))
    return output


def native_attention(model, input_ids):
    starts = model._get_next_start_pos_per_layer()
    q_len, batch = input_ids.shape[1], input_ids.shape[0]
    model._layer_position_ids.clear()
    for layer in range(model.num_layers):
        model._layer_position_ids[layer] = model._build_position_ids(starts[layer], q_len, batch)
    positions = model._build_position_ids(starts[0], q_len, batch)
    model._set_rotary_required_len(max(starts) + q_len)
    legacy = tuple((k.clone(), v.clone()) for k, v in model.kv_cache)
    output = model.language_model(
        input_ids=input_ids, use_cache=False,
        past_key_values=DynamicCache.from_legacy_cache(legacy),
        output_attentions=True, position_ids=positions,
        cache_position=None, attention_mask=None)
    model._layer_position_ids.clear()
    assert output.attentions is not None and len(output.attentions) == model.num_layers
    return list(output.attentions)


def current_attention(model, input_ids):
    return model._compute_attention_scores_manually(input_ids, model.kv_cache)


def compare(path_a, path_b, query, a_name, b_name):
    rows = []
    assert len(path_a) == len(path_b)
    for layer, (a, b) in enumerate(zip(path_a, path_b)):
        assert a.shape == b.shape and a.shape[0] == 1
        x, y = a[0].float().flatten(), b[0].float().flatten()
        cosine = F.cosine_similarity(x, y, dim=0).item()
        difference = (x - y).abs()
        rows.append({"query": query, "comparison": f"{a_name}_vs_{b_name}", "layer": layer,
                     "cosine": cosine, "mean_absolute_difference": difference.mean().item(),
                     "max_absolute_difference": difference.max().item(),
                     "shape": list(a.shape)})
    return rows


def selection_indices(model, attentions, budget):
    local, global_, mixed = [attentions[name] for name in ("local", "global", "mixed")]
    model.token_activity_cache = [None for _ in range(model.num_layers)]
    keep = model.prune_kv_cache_by_attention(local, global_, mixed, num_keep=budget)
    return keep


def compare_selection(model, paths, budget):
    selected = {name: selection_indices(model, value, budget) for name, value in paths.items()}
    visual_count = model.kv_cache[0][0].shape[2] - model.visual_start_idx
    assert visual_count > budget, (visual_count, budget)
    rows = []
    for comparison, a_name, b_name in [("current_vs_native", "current", "native"),
                                       ("causal_frozen_vs_native", "causal_frozen", "native"),
                                       ("current_vs_causal_frozen", "current", "causal_frozen")]:
        for layer, (a, b) in enumerate(zip(selected[a_name], selected[b_name])):
            a = set(a) - set(range(model.visual_start_idx))
            b = set(b) - set(range(model.visual_start_idx))
            assert 0 < len(a) < visual_count and 0 < len(b) < visual_count
            rows.append({"comparison": comparison, "layer": layer, "budget": budget,
                         "visual_tokens": visual_count, "selected_A": len(a), "selected_B": len(b),
                         "intersection": len(a & b), "jaccard": len(a & b) / len(a | b),
                         "symmetric_difference": len(a ^ b),
                         "selected_indices_A": json.dumps(sorted(a)),
                         "selected_indices_B": json.dumps(sorted(b))})
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--model_path", required=True)
    parser.add_argument("--video_path", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--budget", type=int, default=256)
    args = parser.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    from inference.llavaov_hermes import load_model
    torch.manual_seed(2024)
    np.random.seed(2024)
    model, processor = load_model(model_path=args.model_path, kv_size=args.budget,
                                  streaming=True, sample_fps=.5)
    video = load_first_chunk(args.video_path)
    model.encode_init_prompt()
    model.encode_video_chunk(video)
    print('KV_CACHE_TYPE='+type(model.kv_cache).__name__,flush=True)
    past_len = model.kv_cache[0][0].shape[2]
    visual_tokens = past_len - model.visual_start_idx
    assert visual_tokens > args.budget and visual_tokens > 1000
    local, global_ = model.predict_next_question()
    queries = {"local": local, "global": global_, "mixed": local + "; " + global_}
    paths = {}
    for path_name in ("native", "current", "causal_frozen"):
        paths[path_name] = {}
        for query_name, text in queries.items():
            ids = torch.as_tensor([processor.tokenizer(text).input_ids], device=model.device, dtype=torch.int)
            print(f"ATTENTION_START path={path_name} query={query_name} q_len={ids.shape[1]}", flush=True)
            if path_name == "native":
                weights = native_attention(model, ids)
            elif path_name == "current":
                weights = current_attention(model, ids)
            else:
                weights = manual_attention(model, ids, model.kv_cache, causal=True)
            paths[path_name][query_name] = weights
            print(f"ATTENTION_DONE path={path_name} query={query_name}", flush=True)
    metric_rows = []
    for query in queries:
        for comparison, a, b in [("current_vs_native", "current", "native"),
                                 ("causal_frozen_vs_native", "causal_frozen", "native"),
                                 ("current_vs_causal_frozen", "current", "causal_frozen")]:
            metric_rows.extend(compare(paths[a][query], paths[b][query], query, a, b))
    metrics = pd.DataFrame(metric_rows)
    metrics.to_csv(output / "attention_per_layer_metrics.csv", index=False)
    summary = metrics.groupby("comparison").agg(
        layers=("layer", "size"), mean_cosine=("cosine", "mean"), min_cosine=("cosine", "min"),
        mean_absolute_difference=("mean_absolute_difference", "mean"),
        max_absolute_difference=("max_absolute_difference", "max")).reset_index()
    summary.to_csv(output / "attention_summary.csv", index=False)
    selection = pd.DataFrame(compare_selection(model, paths, args.budget))
    selection.to_csv(output / "selection_impact_per_layer.csv", index=False)
    selection.groupby("comparison").agg(layers=("layer", "size"), mean_jaccard=("jaccard", "mean"),
        min_jaccard=("jaccard", "min"), mean_symmetric_difference=("symmetric_difference", "mean")).reset_index().to_csv(
        output / "selection_impact_summary.csv", index=False)
    provenance = {"status": "complete", "video_path_name": Path(args.video_path).name,
                  "video_sha256": sha256(args.video_path), "encoded_frames": 16,
                  "past_tokens": past_len, "visual_tokens": visual_tokens,
                  "visual_start_idx": model.visual_start_idx, "layers": model.num_layers,
                  "topk_budget_per_layer": args.budget, "topk_is_constraining": True,
                  "queries": queries, "query_tokens": {name: len(processor.tokenizer(text).input_ids)
                                                       for name, text in queries.items()},
                  "current": "frozen embeddings; no causal mask",
                  "causal_frozen": "frozen embeddings; causal mask",
                  "native": "causal residual/MLP propagation; DynamicCache reference",
                  "model_path_identity": Path(args.model_path).name,
                  "finished_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    (output / "attention_test_provenance.json").write_text(json.dumps(provenance, indent=2))
    (output / "complete.json").write_text(json.dumps({"status": "complete", "metric_rows": len(metrics),
                                                       "selection_rows": len(selection)}))
    print(summary.to_string(index=False), flush=True)
    print("REAL_VIDEO_ATTENTION_COMPLETE", flush=True)
    del paths, model
    gc.collect()
    torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
