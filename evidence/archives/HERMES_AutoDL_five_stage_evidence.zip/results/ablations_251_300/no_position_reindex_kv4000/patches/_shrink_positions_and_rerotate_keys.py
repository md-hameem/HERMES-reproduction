@torch.inference_mode()
def _shrink_positions_and_rerotate_keys(self, keep_indices_per_layer):
    device = self.device

    curr_lens = self._get_cache_seq_len_per_layer()

    for layer_idx in range(self.num_layers):
        if (self._position_ids_cache[layer_idx] is None or 
            self._position_ids_cache[layer_idx].numel() != curr_lens[layer_idx]):
            self._position_ids_cache[layer_idx] = torch.arange(
                curr_lens[layer_idx], device=device, dtype=torch.long
            )
    max_pos_limit = getattr(self.language_model.config, "max_position_embeddings", 32768)
    compact_threshold = max_pos_limit - 1024

    current_max_pos = 0
    for cache in self._position_ids_cache:
         if cache is not None and cache.numel() > 0:
             current_max_pos = max(current_max_pos, cache[-1].item())

    should_compact = (current_max_pos > compact_threshold) if self.streaming else True

    if should_compact:
        logger.info(f"[Shrink] Max position {current_max_pos} > {compact_threshold}. Compacting position IDs (Shift Left).")

    old_position_ids_cache = [cache.clone() for cache in self._position_ids_cache]

    sample_k = self.kv_cache[0][0]
    dtype = sample_k.dtype

    new_kv_cache = []

    for layer_idx, (k_layer, v_layer) in enumerate(self.kv_cache):

        keep_indices_layer = keep_indices_per_layer[layer_idx]
        if not isinstance(keep_indices_layer, torch.Tensor):
            keep_indices_layer = torch.as_tensor(keep_indices_layer, dtype=torch.long, device=device)

        seq_len_layer = k_layer.shape[2]
        safe_idx = self._sanitize_keep_indices(keep_indices_layer, seq_len_layer)

        if safe_idx.numel() == 0:
            logger.warning(f"Layer {layer_idx}: After sanitization, keep_indices is empty; keeping first token")
            safe_idx = torch.tensor([0], device=device, dtype=torch.long)

        is_long_term = (layer_idx >= self.long_term_threshold)

        # === Extract Kept Tokens ===
        k_kept = torch.index_select(k_layer, dim=2, index=safe_idx)
        v_kept = torch.index_select(v_layer, dim=2, index=safe_idx)
        old_pos_kept = old_position_ids_cache[layer_idx].index_select(0, safe_idx)

        # === Determine New Positions for Kept Tokens ===
        if should_compact and not getattr(self, '_ablate_position_reindex', False):
            new_pos_kept = torch.arange(len(safe_idx), device=device, dtype=torch.long)
        else:
            new_pos_kept = old_pos_kept

        # === Handle RoPE for Kept Tokens ===
        if should_compact and not getattr(self, '_ablate_position_reindex', False):
            cos_old, sin_old = compute_cos_sin_for_positions(
                self.language_model, len(old_pos_kept), old_pos_kept, dtype, device
            )
            cos_new, sin_new = compute_cos_sin_for_positions(
                self.language_model, len(new_pos_kept), new_pos_kept, dtype, device
            )
            cos_delta, sin_delta = rotary_delta(
                cos_old, sin_old, cos_new, sin_new
            )
            k_kept_final = apply_rotary_delta_to_keys_only(k_kept, cos_delta, sin_delta)
        else:
            k_kept_final = k_kept

        # === Handle Folding (Summary Token) for Long-term Layers ===
        if is_long_term:
            mask = torch.ones(seq_len_layer, dtype=torch.bool, device=device)
            mask[safe_idx] = False
            prune_indices = torch.nonzero(mask).squeeze(1)

            if prune_indices.numel() > 0:
                k_pruned = torch.index_select(k_layer, dim=2, index=prune_indices)
                v_pruned = torch.index_select(v_layer, dim=2, index=prune_indices)

                v_summary = v_pruned.mean(dim=2, keepdim=True)

                old_pos_pruned = old_position_ids_cache[layer_idx].index_select(0, prune_indices)

                if should_compact and not getattr(self, '_ablate_position_reindex', False):
                    summary_pos_id = len(safe_idx)
                else:
                    summary_pos_id = new_pos_kept[-1].item() + 1

                summary_pos_tensor = torch.tensor([summary_pos_id], device=device, dtype=torch.long)
                target_pos_pruned = summary_pos_tensor.repeat(old_pos_pruned.shape[0])

                cos_old, sin_old = compute_cos_sin_for_positions(
                    self.language_model, len(old_pos_pruned), old_pos_pruned, dtype, device
                )
                cos_new, sin_new = compute_cos_sin_for_positions(
                    self.language_model, len(target_pos_pruned), target_pos_pruned, dtype, device
                )

                cos_delta, sin_delta = rotary_delta(cos_old, sin_old, cos_new, sin_new)

                k_pruned_aligned = apply_rotary_delta_to_keys_only(k_pruned, cos_delta, sin_delta)

                k_summary_final = k_pruned_aligned.mean(dim=2, keepdim=True)

                k_final = torch.cat([k_kept_final, k_summary_final], dim=2)
                v_final = torch.cat([v_kept, v_summary], dim=2)

                new_pos_layer = torch.cat([new_pos_kept, summary_pos_tensor])

            else:
                k_final = k_kept_final
                v_final = v_kept
                new_pos_layer = new_pos_kept
        else:
            k_final = k_kept_final
            v_final = v_kept
            new_pos_layer = new_pos_kept

        new_kv_cache.append((k_final.contiguous(), v_final.contiguous()))

        self._position_ids_cache[layer_idx] = new_pos_layer.clone()

    self.kv_cache = new_kv_cache

    new_lens = self._get_cache_seq_len_per_layer()
    logger.info(f"Layer-wise shrink completed. Lengths: min={min(new_lens)}, max={max(new_lens)}, "
               f"first={new_lens[0]}, last={new_lens[-1]}")
