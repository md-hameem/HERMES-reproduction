def prune_kv_cache_by_attention(self, attn_weights_local, attn_weights_global, attn_weights_mixed, num_keep=3000):
    device = self.device
    visual_start_idx = self.visual_start_idx
    num_layers = len(attn_weights_local)

    curr_cache_lens = self._get_cache_seq_len_per_layer()

    question_len_local = attn_weights_local[0].shape[2]
    question_len_global = attn_weights_global[0].shape[2]
    question_len_mixed = attn_weights_mixed[0].shape[2]

    total_budget = num_keep * num_layers
    budget_per_layer = self.allocate_budget_by_depth(total_budget, num_layers)

    keep_indices_all_layers = []

    layer_raw_scores = []
    layer_configs = []

    for layer_idx in range(len(attn_weights_local)):
        curr_len = curr_cache_lens[layer_idx]
        if self.token_activity_cache[layer_idx] is None:
            self.token_activity_cache[layer_idx] = torch.zeros(curr_len, device=device, dtype=torch.float32)
        elif self.token_activity_cache[layer_idx].shape[0] < curr_len:
            diff = curr_len - self.token_activity_cache[layer_idx].shape[0]
            zeros = torch.zeros(diff, device=device, dtype=torch.float32)
            self.token_activity_cache[layer_idx] = torch.cat([self.token_activity_cache[layer_idx], zeros])

        if self.token_activity_cache[layer_idx].shape[0] > curr_len:
             self.token_activity_cache[layer_idx] = self.token_activity_cache[layer_idx][:curr_len]

        # Memory hierarchy mode
        if layer_idx < self.short_term_threshold:
            layer_type = "short-term"
            layer_attn_weights = attn_weights_local[layer_idx]
            question_len = question_len_local
            layer_recency_alpha = 1
            k = 20

        elif layer_idx >= self.long_term_threshold:
            layer_type = "long-term"
            layer_attn_weights = attn_weights_global[layer_idx]
            question_len = question_len_global
            layer_recency_alpha = 0
            k = 0.0

        else:
            layer_type = "mid-term"
            layer_attn_weights = attn_weights_mixed[layer_idx]
            question_len = question_len_mixed
            progress = (layer_idx - self.short_term_threshold) / (self.long_term_threshold - self.short_term_threshold)
            layer_recency_alpha = 1.0 - 0.9 * progress
            k = 20 - 19.5 * progress

        visual_attn_weights = layer_attn_weights[0].mean(dim=0)[:,visual_start_idx:-1*question_len].mean(dim=0)
        num_visual_tokens = visual_attn_weights.shape[0]

        end_idx = visual_start_idx + num_visual_tokens
        if end_idx <= self.token_activity_cache[layer_idx].shape[0]:
            self.token_activity_cache[layer_idx][visual_start_idx:end_idx] += visual_attn_weights

        layer_budget = budget_per_layer[layer_idx]

        if layer_type == 'long-term':
            layer_budget = max(0, layer_budget - 1)

        positions = torch.arange(num_visual_tokens, device=device, dtype=torch.float32)
        time_distances = (num_visual_tokens - 1 - positions) / max(num_visual_tokens - 1, 1)

        # Exponential decay
        recency_weights = torch.exp(-k * time_distances)

        attn_norm = (visual_attn_weights - visual_attn_weights.min()) / \
                    (visual_attn_weights.max() - visual_attn_weights.min() + 1e-6)
        recency_norm = (recency_weights - recency_weights.min()) / \
                    (recency_weights.max() - recency_weights.min() + 1e-6)

        raw_score = attn_norm * (1 - layer_recency_alpha) + recency_norm * layer_recency_alpha

        layer_raw_scores.append(raw_score)
        layer_configs.append({
            'budget': min(layer_budget, num_visual_tokens),
            'layer_type': layer_type,
            'visual_start_idx': visual_start_idx
        })

    refined_scores = layer_raw_scores  # ABLATION: no cross-layer smoothing

    for layer_idx, score in enumerate(refined_scores):
        config = layer_configs[layer_idx]
        actual_num_keep = config['budget']
        start_idx = config['visual_start_idx']

        topk_indices_relative = torch.topk(score, actual_num_keep, sorted=False)[1]
        topk_indices_absolute = topk_indices_relative + start_idx
        topk_indices_absolute_sorted = torch.sort(topk_indices_absolute)[0]

        keep_indices = torch.cat([
            torch.arange(start_idx, device=device), 
            topk_indices_absolute_sorted
        ]).tolist()

        keep_indices_all_layers.append(keep_indices)

    return keep_indices_all_layers
